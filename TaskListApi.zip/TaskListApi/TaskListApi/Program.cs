using Microsoft.EntityFrameworkCore;
using TaskListApi.Data;
using TaskListApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<TaskDbContext>(options =>
    options.UseInMemoryDatabase("TaskListDb"));

builder.Services.AddEndpointsApiExplorer();

var app = builder.Build();

// ---------------------------------------------------------------------
// PROBLEM STATEMENT — see README.md for full details.
//
// Implement the following endpoints. Each TODO below tells you what is
// expected; replace the placeholder body with a real implementation.
// ---------------------------------------------------------------------

// TODO 1: GET /api/tasks
//   - Return all tasks as 200 OK.
app.MapGet("/api/tasks", () =>
{
    throw new NotImplementedException("TODO: return all tasks");
});

// TODO 2: GET /api/tasks/{id}
//   - Return the matching task as 200 OK.
//   - Return 404 Not Found if no task with that id exists.
app.MapGet("/api/tasks/{id:int}", (int id) =>
{
    throw new NotImplementedException("TODO: return task by id, or 404");
});

// TODO 3: POST /api/tasks
//   - Accept a CreateTaskRequest body.
//   - Return 400 Bad Request if Title is missing or too long.
//   - Save the new task and return 201 Created with a Location header
//     pointing at GET /api/tasks/{id}.
app.MapPost("/api/tasks", (CreateTaskRequest request) =>
{
    throw new NotImplementedException("TODO: validate and create a task");
});

// TODO 4: PUT /api/tasks/{id}
//   - Accept an UpdateTaskRequest body.
//   - Return 404 Not Found if no task with that id exists.
//   - Return 400 Bad Request if Title is missing or too long.
//   - Update the task and return 200 OK (or 204 No Content).
app.MapPut("/api/tasks/{id:int}", (int id, UpdateTaskRequest request) =>
{
    throw new NotImplementedException("TODO: validate and update a task");
});

// TODO 5: DELETE /api/tasks/{id}
//   - Delete the task and return 204 No Content.
//   - Return 404 Not Found if no task with that id exists.
app.MapDelete("/api/tasks/{id:int}", (int id) =>
{
    throw new NotImplementedException("TODO: delete a task, or 404");
});

// TODO 6 (bonus): add middleware/exception handling so that any
// unhandled exception returns a clean JSON error response instead of
// a raw stack trace. See README.md "Bonus" section.

app.Run();

// Required so WebApplicationFactory<Program> works from the test project.
public partial class Program { }
