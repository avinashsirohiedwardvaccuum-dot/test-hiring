using System.ComponentModel.DataAnnotations;

namespace TaskListApi.Models;

/// <summary>
/// Represents a single item in the task list.
///
/// TODO (candidate): add the missing properties below with appropriate
/// data annotations so that:
///   - Id is the primary key.
///   - Title is required and no longer than 100 characters.
///   - IsComplete defaults to false.
///   - CreatedAt is set automatically when the task is created.
/// </summary>
public class TaskItem
{
    public int Id { get; set; }

    // TODO: add Title (string, [Required], [MaxLength(100)])

    // TODO: add IsComplete (bool, default false)

    // TODO: add CreatedAt (DateTime, default DateTime.UtcNow)
}
