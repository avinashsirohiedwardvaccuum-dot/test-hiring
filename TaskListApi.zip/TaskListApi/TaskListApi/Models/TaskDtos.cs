using System.ComponentModel.DataAnnotations;

namespace TaskListApi.Models;

/// <summary>Payload for creating a new task. TODO: add validation attributes.</summary>
public class CreateTaskRequest
{
    // TODO: Title (string, required, max 100 chars)
}

/// <summary>Payload for updating an existing task. TODO: add validation attributes.</summary>
public class UpdateTaskRequest
{
    // TODO: Title (string, required, max 100 chars)

    // TODO: IsComplete (bool)
}
