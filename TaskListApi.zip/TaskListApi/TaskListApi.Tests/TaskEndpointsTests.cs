using System.Net;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace TaskListApi.Tests;

public class TaskEndpointsTests : IClassFixture<WebApplicationFactory<Program>>
{
    private readonly WebApplicationFactory<Program> _factory;

    public TaskEndpointsTests(WebApplicationFactory<Program> factory)
    {
        _factory = factory;
    }

    // TODO (candidate): implement this test so it verifies that
    // GET /api/tasks/{id} returns 404 Not Found for an id that does
    // not exist.
    [Fact]
    public async Task GetTask_ReturnsNotFound_WhenIdDoesNotExist()
    {
        var client = _factory.CreateClient();

        // TODO: replace with a real request + assertion
        var response = await client.GetAsync("/api/tasks/999999");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode);
    }

    // TODO (candidate, bonus): add at least one more test, e.g. for
    // POST /api/tasks returning 201 Created, or 400 Bad Request when
    // Title is missing.
}
